make clean
make
./bin/splc test/test_11710123_1.spl
./bin/splc test/test_11710123_2.spl
./bin/splc test/test_11710123_3.spl
./bin/splc test/test_11710123_4.spl
./bin/splc test/test_11710123_5.spl
./bin/splc test/test_11710123_6.spl
./bin/splc test/test_11710123_7.spl
./bin/splc test/test_11710123_8.spl
./bin/splc test/test_11710123_9.spl
./bin/splc test/test_11710123_10.spl

