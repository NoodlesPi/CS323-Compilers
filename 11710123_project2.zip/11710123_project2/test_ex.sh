make clean
make
./bin/splc test-ex/test_1.spl
./bin/splc test-ex/test_2.spl
./bin/splc test-ex/test_3.spl

